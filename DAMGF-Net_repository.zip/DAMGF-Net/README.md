# DAMGF-Net: Dynamic Adaptive Multimodal Graph Fusion for Multi-Hazard Recognition

Code and data for the paper:

> D. Mounika, J. Kolluri, S. Srinivas. **DAMGF-Net: Dynamic Adaptive Multimodal Graph Fusion for Multi-Hazard Recognition from Disaster Imagery, Social Media, IoT and Seismic Data — A Controlled Evaluation under Weak Cross-Modal Pairing.** Submitted to *Pattern Analysis and Applications*, 2026.

Zenodo archive: [10.5281/zenodo.XXXXXXX](https://doi.org/10.5281/zenodo.XXXXXXX)

This repository holds everything needed to repeat the experiments, in one place:

- the source code: data download, perceptual-hash de-duplication, cross-modal pairing, the DAMGF-Net model, baselines, ablations, test-time controls, leave-one-source-out testing and cost profiling;
- for every seed: the data splits, the harmonised class mapping, the de-duplication lists and the cross-modal pairing indices (`data/`);
- the result files of the run reported in the paper (`results/paper_run/`).

---

## 1. Repository layout

```
DAMGF-Net/
├── README.md
├── LICENSE                         MIT licence
├── requirements.txt
├── src/
│   └── damgf_experiments.py        full pipeline (model, training, evaluation, all controls)
├── notebooks/
│   └── run_in_colab.ipynb          one-click reproduction in Google Colab
├── scripts/
│   ├── download_data.py            downloads the four public Kaggle datasets
│   └── check_comments_english.py   helper that lists non-ASCII lines in code
├── data/
│   ├── class_mappings/             source folder -> harmonised class; text-pairing keywords
│   ├── dedup/                      pHash of every image; list of removed near-duplicates
│   ├── splits/seed{42,43,44}/      train / val / test image identifiers
│   ├── splits/loso/<source>/       leave-one-source-out splits
│   └── pairing/seed{42,43,44}/     post, sensor and seismic record assigned to every image
└── results/
    ├── paper_run/                  result files behind Tables 10-14 of the paper
    └── run/                        output folder of a new run
```

## 2. Model and pipeline (where to find each part)

All components are in `src/damgf_experiments.py`:

| Paper | Code |
|---|---|
| Image encoder (Swin-Tiny + projection), text encoder (BERT-base + projection) | `make_swin`, `make_bert`, `proj_head` |
| Sensor encoder (Conv1d × 2 + BiLSTM), seismic encoder (MLP), Sect. 4.3.1 | `IoTEncoder`, `SeisEncoder` |
| Adaptive cross-modal attention fusion (ACMAF), Eqs. 5–7 | `ACMAF` |
| Dynamic graph constructor and graph transformer (named STGT/DGT in the paper), Eqs. 8–17 | `GraphModule` |
| Prediction head with auxiliary severity term, Eqs. 18–19 | `FusionModel.shared/cls/sev`, `loss_fn` |
| Baselines and ablations (image-only, text-only, IoT-only, seismic-only, concatenation, ACMAF-only, static graph, full, λ = 0, modality dropout) | `FusionModel(variant=...)`, `VARIANTS` |
| Cross-modal pairing (keyword, keyword-masked, random), Sect. 4.2 | `text_pools`, `make_pairs`, `mask_text` |
| pHash de-duplication (Hamming ≤ 4), Eq. 20 | `phash_all`, `step_audit` |
| Test-time shuffling and modality removal, Eq. 21 | `step_grid` (controls) |
| Adjacency entropy and saturation, Eqs. 22–23 | `adjacency_diag` |
| Metrics (accuracy, macro-F1, MCC, kappa, AUC), Eqs. 24–26 | `metrics` |
| Leave-one-source-out, Eq. 27 | `step_loso` |
| Parameters, GFLOPs, latency, memory | `step_efficiency` |

## 3. Environment

Experiments were run on Google Colab with one NVIDIA Tesla T4 GPU (16 GB).

```bash
git clone https://github.com/GITHUB-USERNAME/DAMGF-Net.git
cd DAMGF-Net
pip install -r requirements.txt
```

The exact package versions of a run are written to `results/run/environment.txt`.

## 4. Data

### 4.1 Source datasets (all public)

| Modality | Kaggle dataset | Records used | Licence | In this repository |
|---|---|---|---|---|
| Images | [`georgemystriotis/disasters-dataset`](https://www.kaggle.com/datasets/georgemystriotis/disasters-dataset): compilation of seven collections (Table 3 of the paper) | 68,308 → 58,927 after de-duplication | per collection: CC0, CC BY 4.0, CC BY-NC-SA 4.0, GPL-2.0, not stated | identifiers only |
| Social-media posts | [`nihajasminesk/disaster-or-not-dataset`](https://www.kaggle.com/datasets/nihajasminesk/disaster-or-not-dataset) (`Tweets.csv`) | 45,384 | CC BY 4.0 | row indices |
| Accelerometer and gyroscope | [`aaryapandya/earthquake-detection`](https://www.kaggle.com/datasets/aaryapandya/earthquake-detection) (`Data.csv`) | 59,276 | LGPL-3.0 | row indices |
| Seismic catalogue | [`ahmeduzaki/earthquake-alert-prediction-dataset`](https://www.kaggle.com/datasets/ahmeduzaki/earthquake-alert-prediction-dataset) | 1,300 | CC BY 4.0 | row indices |

Images are not redistributed, because two collections carry no licence statement and one is CC BY-NC-SA 4.0. The download script fetches the original files and every released file refers to them by identifier.

### 4.2 Download

1. Create a Kaggle API token (Kaggle → Settings → API → *Create New Token*) and save it as `~/.kaggle/kaggle.json`.
2. Run:

```bash
python scripts/download_data.py --out data/MultiHazard
```

### 4.3 Released files in `data/`

| File | Content |
|---|---|
| `class_mappings/class_mapping.csv` | source folder name → harmonised class (earthquake, flood, fire, smoke, normal) |
| `class_mappings/text_pairing_keywords.csv` | keywords that define each class's post pool, pool sizes, severity targets |
| `dedup/phash.csv` | `image_id, source, label, phash, kept` for all 68,308 images |
| `dedup/removed.csv` | each removed image, the earlier image it duplicates, its source and the Hamming distance |
| `splits/seed{42,43,44}/{train,val,test}.csv` | `image_id, source, label` (70/15/15, stratified, de-duplicated corpus) |
| `splits/loso/<source>/{train,val,test}.csv` | leave-one-source-out splits (seed 42) |
| `pairing/seed{s}/{keyword,random_text}_{train,val,test}.csv` | `image_id, label, post_row, sensor_row, seismic_row, severity_target` |

- `image_id` is the path of the image relative to `data/MultiHazard/RemoteSensing/`.
- `post_row`, `sensor_row` and `seismic_row` are 0-based row indices in `Tweets.csv`, `Data.csv` and `earthquake_alert_balanced_dataset.csv`.
- The keyword-masked condition uses the same indices as `keyword_*`, with every pairing keyword replaced by `[MASK]` before encoding (`mask_text`).
- All files are regenerated by the pipeline. The `EXPORT` step writes them from the same functions and seeds used for training.

## 5. Reproducing the experiments

### Option A: Google Colab (recommended)

Open `notebooks/run_in_colab.ipynb` in Colab, select a T4 GPU and run the cells in order. It downloads the data, runs every experiment and gives you a zip file containing `data/` and `results/run/`.

### Option B: command line (one GPU)

```bash
python scripts/download_data.py --out data/MultiHazard
python src/damgf_experiments.py
```

| Pipeline step | Paper output | Written to |
|---|---|---|
| STEP 1: image audit, pHash de-duplication, near-duplicate leakage | Table 3 (after de-duplication), Sect. 5.7, Fig. 2 | `results/run/audit.json`, `fig_examples_per_class.png`, `data/dedup/` |
| EXPORT: splits and pairing indices | Sect. 4.2, 4.7 | `data/splits/`, `data/pairing/`, `data/class_mappings/` |
| STEP 2: frozen Swin-Tiny / BERT features | — | `results/run/cache/` |
| STEP 3: baselines, ablations, three pairings, three seeds; test-time interventions; adjacency diagnostics | Tables 10, 11, Sect. 5.8 | `results/run/grid.json` |
| STEP 4: leave-one-source-out | Table 12 | `results/run/loso.json` |
| STEP 6: parameters, GFLOPs, latency, memory | Table 14 | `results/run/efficiency.json` |
| STEP 7: summary of all tables | — | `results/run/RESULTS_FOR_PAPER.md` |

Running time on a Colab T4: about 1–2 hours in total, most of it feature caching. Every step is resumable.

Quick check without data (synthetic, about 2 minutes, needs internet for the pretrained tokenizer):

```bash
DAMGF_SMOKE=1 python src/damgf_experiments.py
```

Optional end-to-end fine-tuning of the image-only and full models (keyword-masked text, several hours):

```bash
DAMGF_FINETUNE=1 python src/damgf_experiments.py
```

### Expected results

Controlled protocol, de-duplicated corpus, mean ± sd over seeds 42–44 (Table 10):

| Variant | Text pairing | Accuracy (%) |
|---|---|---|
| Image only | — | 95.94 ± 0.19 |
| Text only | keyword | 69.56 ± 2.21 |
| Text only | keyword-masked | 70.74 ± 1.49 |
| Text only / IoT only / seismic only | random / — / — | 30.21 (majority class) |
| Full DAMGF-Net | keyword | 95.56 ± 0.28 |
| Full DAMGF-Net | keyword-masked | 96.44 ± 0.23 |
| Full DAMGF-Net | random | 95.86 ± 0.31 |

Other checks: near-duplicates in a random split of the original corpus, 1,788 of 10,247 test images (17.45%); leave-one-source-out mean accuracy, 76–77%; full model with backbones, 15.42 GFLOPs per sample and 24.59 ms latency at batch size 1 on a T4 (Table 14).

The complete result files of the run reported in the paper are in `results/paper_run/`. A new run can differ slightly, by about the seed standard deviations, because of non-deterministic CUDA kernels and library versions.

## 6. Training settings

- **Controlled protocol** (all variants, same procedure): frozen Swin-Tiny and BERT-base features; AdamW (lr 1e-3, weight decay 1e-4), cosine schedule, batch size 256, at most 30 epochs, early stopping with patience 5 on validation loss, label smoothing 0.1, λ = 0.30, gradient clipping 1.0.
- **Model**: 512-d embeddings, graph transformer with 2 layers, 8 heads, FFN 2048; dropout 0.30.
- **Images**: resize to 256, centre crop 224, ImageNet normalisation. Text: BERT tokenizer, maximum 128 tokens, raw posts. Sensor and seismic values are used unscaled.

## 7. Citation

```bibtex
@article{mounika2026damgf,
  title   = {DAMGF-Net: Dynamic Adaptive Multimodal Graph Fusion for Multi-Hazard Recognition from Disaster Imagery, Social Media, IoT and Seismic Data---A Controlled Evaluation under Weak Cross-Modal Pairing},
  author  = {Mounika, Dannuri and Kolluri, Johnson and Srinivas, Sunil},
  journal = {Pattern Analysis and Applications},
  year    = {2026},
  note    = {Under review}
}
```

## 8. Licence and contact

The code is released under the MIT licence (`LICENSE`). The source datasets keep their original licences (Section 4.1).

Corresponding author: Johnson Kolluri, johnson.kolluri@gmail.com
